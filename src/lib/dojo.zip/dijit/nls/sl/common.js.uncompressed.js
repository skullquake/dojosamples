define(
"dijit/nls/sl/common", ({
	buttonOk: "V redu",
	buttonCancel: "Prekliči",
	buttonSave: "Shrani",
	itemClose: "Zapri"
})
);
