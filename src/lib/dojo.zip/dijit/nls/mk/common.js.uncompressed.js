define("dijit/nls/mk/common", {      
//begin v1.x content
	buttonOk: "OK",
	buttonCancel: "Откажи",
	buttonSave: "Зачувај",
	itemClose: "Затвори"
//end v1.x content
});

