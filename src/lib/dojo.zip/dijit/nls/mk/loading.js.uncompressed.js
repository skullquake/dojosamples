define("dijit/nls/mk/loading", {      
//begin v1.x content
	loadingState: "Вчитување...",
	errorState: "Се појави грешка"
//end v1.x content
});

