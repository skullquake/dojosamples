define("dijit/nls/eu/loading", {      
//begin v1.x content
	loadingState: "Kargatzen...",
	errorState: "Barkatu, errorea gertatu da"
//end v1.x content
});

