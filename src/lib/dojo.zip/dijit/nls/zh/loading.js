//>>built
define("dijit/nls/zh/loading",({loadingState:"正在加载...",errorState:"对不起，发生了错误"}));
